//@line 36 "/builds/slave/linux_repack/build/releases/l10n-mozilla-1.9.1/fr/suite/suite-l10n.js"

//@line 38 "/builds/slave/linux_repack/build/releases/l10n-mozilla-1.9.1/fr/suite/suite-l10n.js"

pref("general.useragent.locale", "fr");
pref("spellchecker.dictionary", "fr");
